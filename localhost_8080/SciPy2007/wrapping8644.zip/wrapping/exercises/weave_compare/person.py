from enthought.traits.api import HasTraits, Float, Str, Enum


class Person(HasTraits):
	first_name = Str('Joe')
	last_name = Str('Doe')
	age = Float
	gender = Enum('male','female')

	def _age_changed(self, old, new):
		print 'new age:', self.age
		
person = Person()	