import example

print 'fact(10):', example.fact(10)