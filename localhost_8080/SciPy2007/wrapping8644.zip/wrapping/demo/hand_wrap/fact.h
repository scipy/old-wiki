#ifndef FACT_H
#define FACT_H

int fact(int n);

#endif
