#!/usr/bin/env python
import os
import os.path as op
from optparse import OptionParser
import pyparsing as pp

from gendocslib.parseDocs import createBNFSections, createBNFArgs

latex = 'pdflatex'
latexOptions = r'-interaction=\nonstopmode'
latexRuns = 3
outputDir = '.'

defines = r"""
\def\figDir{%s/figures}
"""

header = r"""
\documentclass[10pt,a4paper]{article}

\usepackage{bm}
\usepackage{a4wide}

%s

\setlength{\parindent}{0pt}
\set
\newif\ifPDF
\ifx\pdftexversion\undefined \PDFfalse
\else \PDFtrue
\fi

\ifPDF
   \usepackage[pdftex]{graphicx}
   \DeclareGraphicsExtensions{.pdf,.png}
   \pdfinfo{
    /Title      (Documentation for module %s)
    /Author     (%s)
  }
\else
  \usepackage{graphicx}
  \DeclareGraphicsExtensions{.eps}
\fi

\setcounter{page}{%d}

\begin{document}

%s

\tableofcontents

\newpage

"""

ending = r"""
\end{document}
"""

itemSection = r"""
\textbf{%s}:"""

def protect( st ):
    isMath = False
    st2 = list( st )
    ii2 = 0
    for ii, ch in enumerate( st ):
        if ch == '$':
            isMath = not isMath
        if not isMath and (ch in '^_' ):
            st2.insert( ii2, '\\' )
            ii2 += 1
        ii2 += 1
    return ''.join( st2 )

def typesetText( fd, text, codes ):
    for ii, txt in enumerate( text ):
        if codes[ii]:
            fd.write( r'\begin{verbatim}' )
            fd.write( txt )
            fd.write( r'\end{verbatim}' )
        else:
            fd.write( protect( txt ) )
            

def typesetContents( fd, name, text ):
    text = protect( text )
    fd.write( itemSection % name )
    fd.write( r'{%s}' % text )
    fd.write( '\n' )
    
    
def typesetArguments( fd, argsText, bnf ):
#    print argsText
    out = bnf.parseString( protect( argsText ) )

    fd.write( r'\begin{center}' )
    fd.write( '\n' )
    fd.write( r'\begin{tabular}{rcp{0.7\linewidth}}' )
    fd.write( '\n' )
    for argDesc in out.args:
        fd.write( r'%s & \dots & %s \\' % (argDesc.argName,
                                           argDesc.shortDesc) )
        fd.write( '\n' )
        if argDesc.longDesc:
            fd.write( r'& & %s \\' % ' '.join( argDesc.longDesc ) )
            fd.write( '\n' )

    fd.write( r'\end{tabular}' )
    fd.write( '\n' )
    fd.write( r'\end{center}' )
    fd.write( '\n' )

def typeset( fd, obj, heading, ignore ):
    secList = []
    currentSection = [None]
    bnf = createBNFSections( secList, currentSection )
    bnfArgs = createBNFArgs()

    secTypes = {'=' : r'\sub', '-' : r'\subsub'}

    doc = obj.__doc__
    out = bnf.parseString( doc )
#    out.dump()
    fd.write( heading % protect( ' '.join( (obj.__class__.__name__.capitalize(),
                                            obj.__name__) ) ) )

    contents = None
    for secName, secText in secList:
        level = None
        if type( secName ) == tuple:
            secName, level = secName
##         print secName, level, type( level )
##         raw_input()
        
##         print secText
        text = secText.strip().split( '<code>' )
        if secText.startswith( '<code>' ):
            isCode = True
        else:
            isCode = False
        codes = []
        for txt in text:
            codes.append( isCode )
            isCode = not isCode
            
        if secName is not None:
            if secName in ignore: continue
            if secName == 'Contains':
                typesetContents( fd, secName, secText )
                contents = [st.strip() for st in secText.split( ',' )]
            elif secName == 'Parameters':
                fd.write( itemSection % secName.capitalize() )
                typesetArguments( fd, secText, bnfArgs )
            elif secName == 'Returns':
                fd.write( itemSection % secName.capitalize() )
                typesetArguments( fd, secText, bnfArgs )
            else:
                if level:
                    sub = secTypes[level[0][0]]
                    fd.write( (sub + heading[1:]) % secName.capitalize() )
                else:
                    fd.write( itemSection % secName.capitalize() )
                fd.write( '\n\n' )
                typesetText( fd, text, codes )
                fd.write( '\n\n' )
        elif secText:
            fd.write( '\n\n' )
            typesetText( fd, text, codes )
            fd.write( '\n\n' )
    return contents

usage = """%prog [options]"""
help = {
    'authorName' :
    'name of module/documentation author [default: %default]',
    'moduleName' :
    'name of module to generate documentation for [default: %default]',
    'titleFile' :
    'LaTeX template for title page [default: %default]',
    'outputFileBase' :
    'basename of output file [default: module name]',
    'page' :
    'the first page [default: %default]',
}


def main():
    parser = OptionParser( usage = usage, version = "%prog" )
    parser.add_option( "-a", "--author", metavar = 'authorName',
                       action = "store", dest = "authorName",
                       default = "gendocs.py", help = help['authorName'] )
    parser.add_option( "-m", "--module", metavar = 'moduleName',
                       action = "store", dest = "moduleName",
                       default = "numpy.lib.arraysetops",
                       help = help['moduleName'] )
    parser.add_option( "-t", "--title-file", metavar = 'titleFile',
                       action = "store", dest = "titleFile",
                       default = "pages/title_generic.tex",
                       help = help['titleFile'] )
    parser.add_option( "-o", "--output-file", metavar = 'outputFileBase',
                       action = "store", dest = "outputFileBase",
                       default = None, help = help['outputFileBase'] )
    parser.add_option( "-p", "--page", metavar = 'page', type = "int",
                       action = "store", dest = "page",
                       default = 1, help = help['page'] )
    (options, args) = parser.parse_args()

    mod = __import__( options.moduleName, globals(), locals(), ['None'] )
    print 'generating docs for "%s"...' % mod.__name__

    title = 'Documentation for module %s' % options.moduleName

    if options.outputFileBase:
        latexFileName = options.outputFileBase + '.tex'
    else:
        latexFileName = options.moduleName + '.tex'
    latexFileNameComplete = op.join( outputDir, latexFileName )
    print 'output LaTeX source file: %s' % latexFileNameComplete

    fdt = open( options.titleFile, 'r' )
    titleSrc = fdt.read()
    fdt.close()

    completeTitle = titleSrc % (title, options.authorName)
    completeDefines = defines % '.'

    fd = open( latexFileNameComplete, 'w' )
    fd.write( header % (completeDefines, title,
                        options.authorName, options.page, completeTitle) )
    fd.write( '\n' )
    contents = typeset( fd, mod,
                        heading = r'\section{%s}', ignore = ['Author'] )

    print contents

    if contents:
        fd.write( r'\subsection{Functions}' )
        fd.write( '\n' )
        for item in contents:
            try:
                typeset( fd, getattr( mod, item ),
                         heading = r'\subsubsection{%s}', ignore = ['See also'] )
            except:
                pass

    fd.write( ending )
    fd.close()

    cdIn = 'cd %s;' % outputDir
    cdOut = 'cd %s;' % os.curdir
    
    cmd = ' '.join( (cdIn,
                     latex, latexOptions, latexFileName, ';',
                     cdOut) )
    for ii in xrange( latexRuns ):
        os.system( cmd )

if __name__ == '__main__':
    main()
