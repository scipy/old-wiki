#! /usr/bin/env python
from distutils.core import setup
import os.path as op

import numpy

def setup_package():

    setup( name         = 'gendocs',
           version      = '00.00.02',
           description  = 'typeset in pdfLaTeX the docstrings of NumPy/SciPy modules',
           author       = 'Robert Cimrman',
           author_email = 'cimrman3 (at) ntc (dot) zcu (dot) cz',
           license      = 'BSD',
           url          = '',
           scripts      = ['gendocs.py'],
           packages     = ['gendocslib']
    )

if __name__ == '__main__':
    setup_package()
