gendocs.py is a very simple script that can generate documentation (in PDF
format) from docstrings of NumPy/SciPy modules using pdfLaTeX.

It depends on pyparsing (http://pyparsing.wikispaces.com) by Paul McGuire.

There is no installation, just run the gendocs.py script. Title page templates
are in 'pages' directory.

Run './gendocs.py --help' to see options.

Tested with

./gendocs.py -m 'numpy.lib.arraysetops'
./gendocs.py -m 'scipy.linsolve.umfpack'

- look at the documentation of those modules to see the necessary formatting.

--
Robert Cimrman
