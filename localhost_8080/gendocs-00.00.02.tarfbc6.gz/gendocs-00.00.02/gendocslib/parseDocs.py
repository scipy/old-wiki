import pyparsing as pp

##
# 09.11.2007, c
# 13.11.2007
def setSection( sec ):
    def action( str, loc, toks ):
        if toks:
            print toks
            sec[0] = (toks.section, toks.level)
        return toks
    return action

##
# 09.11.2007, c
def toList( slist, sec ):
    def action( str, loc, toks ):
        if toks:
##             print toks
##             pause()
            slist.append( (sec[0], toks[0]) )
        return toks
    return action

##
# Thanks to Paul McGuire.
def leadingChar(pe):
    def pa(s,l,t):
        thisLine = pp.line(l,s)
        thisCol = pp.col(l,s)
        if pe.preParse(thisLine,0) != thisCol-1:
            raise pp.ParseException("",l,"")
    return pe.setParseAction(pa)

##
# Thanks to Paul McGuire.
def createBNFArgs():
    pp.ParserElement.setDefaultWhitespaceChars(" \t")
    NL = pp.LineEnd().suppress()
    DASH = pp.Literal("-").suppress()
    colon = pp.Literal( ':' ).suppress()
    endOfShortDesc = (pp.Literal( ',' ) | pp.StringEnd() | pp.LineEnd() ).suppress()
    lineNotStartingWithDash = ~leadingChar(DASH) + pp.Empty() + pp.restOfLine + NL
    printablesWithoutComma = pp.printables.replace(",","")
    arg = pp.Group(leadingChar(DASH) + pp.SkipTo(colon)('argName') + colon + \
            pp.restOfLine('shortDesc') + \
            pp.Optional(",").suppress() + NL + \
            pp.ZeroOrMore(~pp.StringEnd() + lineNotStartingWithDash)('longDesc'))
    return pp.OneOrMore(pp.ZeroOrMore(NL) + arg)( 'args' )
    
##
# 09.11.2007, c
# 13.11.2007
def createBNFSections( slist, currentSection ):
    
    colon = pp.Literal( ':' ).suppress()

    section = pp.Combine( colon
                          + pp.Word( pp.alphas, pp.alphanums + '_ ' )
                          + colon )( 'section' )\
              + (pp.ZeroOrMore( (pp.Word( "=", min = 3 )
                                 | pp.Word( "-", min = 3 ) ) ) )( 'level' )
    section.setParseAction( setSection( currentSection ) )
#    section.setDebug()

    text = pp.SkipTo( section | pp.StringEnd() )( 'text' )
    text.setParseAction( toList( slist, currentSection ) )
#    text.setDebug()

    doc = pp.StringStart()\
           + pp.Optional( text ) + pp.ZeroOrMore( section + text )\
           + pp.StringEnd()

    return doc
